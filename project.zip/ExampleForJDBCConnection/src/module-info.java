/**
 * 
 */
/**
 * 
 */
module ExampleForJDBCConnection {
	requires java.sql;
}