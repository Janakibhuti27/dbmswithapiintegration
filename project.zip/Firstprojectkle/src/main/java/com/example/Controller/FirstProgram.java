package com.example.Controller;


import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller

public class FirstProgram {
	
	@RequestMapping("/test")
	@ResponseBody
	public String show()
	{
		return "Good morning!!!";
	}

}
