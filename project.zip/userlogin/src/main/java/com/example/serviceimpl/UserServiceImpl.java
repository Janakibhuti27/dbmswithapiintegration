package com.example.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.User;
import com.example.model.UserDTO;
import com.example.repositary.UserRepository;
import com.example.service.UserService;
import com.example.util.Converter;

@Service

public class UserServiceImpl implements UserService{
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private Converter converter;
	
	//this method is created to save new resource
	
	public UserDTO saveUser(User user)
	{
		return converter.convertUserToUserDTO(userRepository.save(user));
	}
	
	//this method is created to fetch all resource
	
	public List<UserDTO> getAllUsers()
	{
		List<User> users = userRepository.findAll();
		
		//creating the List of UserDTO to store DTO objects 
		List<UserDTO> userDto = new ArrayList<>();
		
		//convert entity to DTO and share in the List
		
		for(User user : users)
		{
		  userDto.add(converter.convertUserToUserDTO(user));
		}
		return userDto;
		
	}
	
	//this method is created to update resource based on id
	public UserDTO updateUser(int id, User user) {
		User existingUSer = userRepository.findById(id).get();
		existingUSer.setUserName(user.getUserName());
		existingUSer.setEmail(user.getEmail());
		existingUSer.setPassword(user.getPassword());
		return converter.convertUserToUserDTO(userRepository.save(existingUSer));
	}
	
	//this method is created to deactivate resource based on id
	public String deactivateUser(int userId)
	{
		userRepository.deleteById(userId);
		return "The user's account has been deactivated.";
	
	}
	

}
